<?php
$servername = "localhost";
$username = "root";
$password = "";
$mydb="students";

// Create connection
$conn = new mysqli($servername,$username,
$password,$mydb);

//check connection

if($conn)
{
	echo("Connection established ");
}

else{
	echo("connection failed");
}

?> 

