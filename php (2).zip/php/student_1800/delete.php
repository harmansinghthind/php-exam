<?php
	include('connect.php');
	$delete_record=$_GET['delete'];
	
	$sql="delete from mytable where id=$delete_record ";
	
	if ($conn->query($sql) === TRUE) 
	{
    echo "<script>alert('Record deleted successfully')</script>";
	include('view.php');
	exit();
		} 
		else
 {
    echo "Error deleting record: " . $conn->error;
}
?>