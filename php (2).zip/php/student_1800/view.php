<?php
	include('connect.php');
?>
<html>
	<head>
		 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"></link>

	</head>
	<body>	
		<H1>RECORD</H1>
		<table border="1" class="table table-hover">
			<tr>
				<th>ID</th>
				<th>FIRST NAME</th>
				<th>lAST NAME</th>
				<th>EMAIL</th>
				<th>DELETE</th>
				<th>UPDATE</th>
			</tr>
			<?php
				$sql="select * from mytable";
				$result=$conn->query($sql);
				
				if($result->num_rows>0)
				{
					while($row=$result->fetch_assoc())
					{
					
					?>
						<tr>
							<td><?php echo $row['id'];?></td>
							<td><?php echo $row['fname'];?></td>
							<td><?php echo $row['lname'];?></td>
							<td><?php echo $row['email'];?></td>
							<td><a href="delete.php?delete=<?php echo $row['id']?>">Delete</a></td>
							<td><a href="">Edit</a></td>
						</tr>
					<?php
					}
				}
				else{
					echo "No data exists";
				}
			?>
		</table>
  </body>
</html>