<html>
	<head>
	</head>
	<body>
		<?php include('header.php');?>
		<form action="math1.php" method="post">
			Number1: <input type="text" name="num">
			<input type="submit" name="submit" value="continue">
		</form>
	</body>
</html>