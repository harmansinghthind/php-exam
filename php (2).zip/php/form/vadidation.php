<?php

    $namerr=$emailrr=$radiorr="";
    $name=$email=$radio="";

if($_SERVER["REQUEST_METHOD"]=="POST"){
    if(empty($_POST["name"])){
        $namerr="fillname";
    }else{
        $name=test_input($_POST["name"]);
    }
    if(!preg_match("/^[a-zA-Z ]*$/",$name)){
        $namerr="onlyletters";
    }
    
    
    
    if(empty($_POST["email"])){
        $emailrr="fillemail";
    }else{
        $email=test_input($_POST["email"]);
    }if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        $emailrr="invalid";
    }
    
    if(empty($_POST["radio"])){
        $radiorr="fill";
    }else{
        $radiorr=test_input($_POST["radio"]);
    }
}


function test_input($data){
    $data=trim($data);
    $data=stripslashes($data);
    $data=htmlspecialchars($data);
}

?>


<html>
<body>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    
    <label>name</label><input type="text" name="name">
    <span class="err"><?php echo $namerr; ?></span>
        <br>

    <label>email</label><input type="text" name="email">
    <span class="err"><?php echo $emailrr; ?></span>
        <br>

    <label>gender</label>Male<input type="radio"  name="radio">
    Female<input type="radio" name="radio">
    <span><?php echo $radiorr ?></span>
    <br>
    <input type="submit" value="submit" name="submit">
</form>    
</body>
</html>